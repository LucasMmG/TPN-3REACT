# TP3 REACT

Hacer una app en react que: tenga un control de formulario HTML input de tipo "text" y un botón que al presionarse muestre en un alert la cantidad de vocales ingresadas (realizarlo con una función de devuelva el resultado).
